from nested_data import albums

print(albums)
